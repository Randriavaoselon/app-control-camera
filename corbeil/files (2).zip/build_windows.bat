@echo off
rem ===========================================================================
rem  Fabrique les programmes Windows du client camera :
rem    dist\CameraClient.exe           sans fenetre (usage normal, demarrage auto)
rem    dist\CameraClient-console.exe   avec console (diagnostic : --debug, --once)
rem
rem  A lancer sur un PC Windows avec Python 3.10+ (python.org).
rem  Double-cliquez, ou lancez depuis une invite de commandes.
rem ===========================================================================
cd /d "%~dp0..\.."

echo [1/3] Environnement de construction...
python -m venv build\venv || goto :error
call build\venv\Scripts\activate.bat || goto :error
python -m pip install --upgrade pip || goto :error
python -m pip install --upgrade pyinstaller -r requirements.txt || goto :error

echo [2/3] Construction de CameraClient.exe (sans fenetre)...
pyinstaller --noconfirm --clean --onefile --noconsole --name CameraClient ^
  --specpath build --workpath build\work-gui --distpath dist "client.py" || goto :error

echo [3/3] Construction de CameraClient-console.exe (diagnostic)...
pyinstaller --noconfirm --onefile --console --name CameraClient-console ^
  --specpath build --workpath build\work-console --distpath dist "client.py" || goto :error

where ISCC >nul 2>nul
if errorlevel 1 (
  echo.
  echo [Info] Inno Setup ^(ISCC^) introuvable : l'installateur CameraClient-Setup.exe
  echo        n'a pas ete cree. Installez Inno Setup ^(https://jrsoftware.org/isinfo.php^)
  echo        puis relancez ce script pour obtenir l'installateur complet.
  echo        En attendant, dist\CameraClient.exe fonctionne deja seul ^(pas besoin de Python^).
  pause
  exit /b 0
)

echo [Bonus] Construction de l'installateur Windows (CameraClient-Setup.exe)...
ISCC build\windows\installer.iss || goto :error

echo.
echo Termine. Fichiers crees :
echo   dist\CameraClient.exe              (programme seul, aucun Python requis)
echo   dist\CameraClient-console.exe      (diagnostic : --debug --once)
echo   releases\CameraClient-Setup.exe    (installateur complet, a mettre sur le serveur)
pause
exit /b 0

:error
echo.
echo ERREUR : la construction a echoue (voir les messages ci-dessus).
pause
exit /b 1
