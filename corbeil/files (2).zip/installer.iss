; Installateur Windows du client caméra.
; Nécessite Inno Setup (gratuit) : https://jrsoftware.org/isinfo.php
; Compilation : ISCC build\windows\installer.iss
; (le script build_windows.bat le fait automatiquement s'il trouve ISCC)
;
; Le résultat, CameraClient-Setup.exe, ne nécessite PAS Python sur la
; machine de l'utilisateur : dist\CameraClient.exe (fabriqué par
; PyInstaller) embarque déjà tout l'interpréteur.

#define MyAppName "Camera Client"
#define MyAppVersion "1.0"
#define MyAppExeName "CameraClient.exe"

[Setup]
AppId={{2F2C5B3E-7A1D-4B7A-9B2E-CAMERACLIENT1}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=Selon Randriavao
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\..\releases
OutputBaseFilename=CameraClient-Setup
Compression=lzma
SolidCompression=yes
UninstallDisplayIcon={app}\{#MyAppExeName}

[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"

[Files]
Source: "..\..\dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Tasks]
Name: "autostart"; Description: "Démarrer automatiquement avec Windows"; GroupDescription: "Options :"; Flags: checkedonce

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Désinstaller {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{userstartup}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: autostart

[Run]
; Enregistre l'adresse du serveur saisie pendant l'installation
Filename: "{app}\{#MyAppExeName}"; Parameters: "--server ""{code:GetServerURL}"" --save --once"; \
    Flags: runhidden waituntilterminated; StatusMsg: "Configuration du serveur..."
; Lance le programme à la fin de l'installation
Filename: "{app}\{#MyAppExeName}"; Description: "Lancer {#MyAppName} maintenant"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Retire aussi la configuration et les logs (dans %LOCALAPPDATA%\CameraClient)
Type: filesandordirs; Name: "{localappdata}\CameraClient"

[Code]
var
  ServerPage: TInputQueryWizardPage;

procedure InitializeWizard;
begin
  ServerPage := CreateInputQueryPage(wpSelectTasks,
    'Adresse du serveur', 'À quel serveur ce client doit-il se connecter ?',
    'Indiquez l''URL complète de votre serveur, par exemple :' + #13#10 +
    'https://ton-utilisateur.pythonanywhere.com');
  ServerPage.Add('URL du serveur :', False);
  ServerPage.Values[0] := 'https://127.0.0.1:5050';
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = ServerPage.ID then
  begin
    if Trim(ServerPage.Values[0]) = '' then
    begin
      MsgBox('Merci de renseigner l''adresse du serveur.', mbError, MB_OK);
      Result := False;
    end;
  end;
end;

function GetServerURL(Param: string): string;
begin
  Result := Trim(ServerPage.Values[0]);
end;
