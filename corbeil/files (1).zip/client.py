"""
Client caméra — se connecte au serveur par HTTP, depuis n'importe quel réseau Wi-Fi.

Fonctionnement :
  - Interroge régulièrement /api/command pour savoir si la caméra doit
    être allumée ou éteinte.
  - Une fois allumée, capture et envoie les images à /api/frame.

Comme pour Wifi Tracker, seule l'URL publique du serveur est nécessaire :
aucune configuration réseau particulière côté client.
"""

import time
import threading

import cv2
import requests

SERVER_URL = "http://127.0.0.1:5050"   # à remplacer par l'URL publique du serveur
POLL_INTERVAL = 1.0       # secondes entre deux vérifications de commande
FRAME_INTERVAL = 0.1      # secondes entre deux images envoyées (~10 im/s)
REQUEST_TIMEOUT = 5


class CameraClient:
    def __init__(self, server_url: str = SERVER_URL):
        self.server_url = server_url.rstrip("/")
        self.camera_on = False
        self.capture: cv2.VideoCapture | None = None
        self._stop_streaming = threading.Event()

    def start(self) -> None:
        print(f"[CLIENT] Connexion au serveur : {self.server_url}")
        while True:
            try:
                self._check_command()
            except requests.RequestException as exc:
                print(f"[CLIENT] Serveur injoignable ({exc}), nouvelle tentative...")
            time.sleep(POLL_INTERVAL)

    def _check_command(self) -> None:
        response = requests.get(f"{self.server_url}/api/command", timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        command = response.json().get("command")

        if command == "START_CAMERA" and not self.camera_on:
            self._start_camera()
        elif command == "STOP_CAMERA" and self.camera_on:
            self._stop_camera()

    def _start_camera(self) -> None:
        self.capture = cv2.VideoCapture(0)
        if not self.capture.isOpened():
            print("[CLIENT] Impossible d'ouvrir la caméra")
            self.capture = None
            return

        self.camera_on = True
        self._stop_streaming.clear()
        threading.Thread(target=self._stream_frames, daemon=True).start()
        print("[CLIENT] Caméra allumée")

    def _stop_camera(self) -> None:
        self.camera_on = False
        self._stop_streaming.set()
        if self.capture is not None:
            self.capture.release()
            self.capture = None
        print("[CLIENT] Caméra éteinte")

    def _stream_frames(self) -> None:
        while not self._stop_streaming.is_set() and self.capture is not None:
            ok, frame = self.capture.read()
            if not ok:
                continue

            ok, buffer = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
            if not ok:
                continue

            try:
                requests.post(
                    f"{self.server_url}/api/frame",
                    data=buffer.tobytes(),
                    headers={"Content-Type": "application/octet-stream"},
                    timeout=REQUEST_TIMEOUT,
                )
            except requests.RequestException:
                pass  # on retentera à la prochaine image

            time.sleep(FRAME_INTERVAL)


if __name__ == "__main__":
    CameraClient().start()
